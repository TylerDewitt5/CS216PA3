#include <iostream>
#include <fstream>
#include <cstring>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <set>
#include <map>
#include <vector>

#include "Matrix.h"
#include "Graph.h"


using namespace std;

int main()
{

	string file1, file2, file3;
	cout << "Please type the name of the file which contains actor IDs and names (default file name is \"actors.txt\")" << endl;
	getline(cin, file1);

	cout << "please type the name of the file which contains movie IDs and titles (default file name is \"movies.txt\")" << endl;
	getline(cin, file2);

	cout << "Please type the name of the file which contains movies IDs and actor IDs (default file name is \"movie-actor.txt\")" << endl;
	getline(cin, file3);

	ifstream in_file1;
	ifstream in_file2;
	ifstream in_file3;

	if (file1 == "")
	{
		in_file1.open("actors.txt");
		if (!in_file1.good())
		{
			cout << "Warning: cannot open file named actors.txt" << endl;
			return 1;
		}
	}
	else
	{
		in_file1.open(file1.c_str());
                if (!in_file1.good())
                {
                        cout << "Warning: cannot open file named " << file1 << endl;
                        return 1;
                }
	}

	if (file2 == "")
	{
		in_file2.open("movies.txt");
                if(!in_file2.good())
                {
                        cout << "Warning: cannot open file named movies.txt" << endl;
                        return 1;
                }

	}
 	else
        {
                in_file2.open(file2.c_str());
                if (!in_file2.good())
                { 
                        cout << "Warning: cannot open file named " << file2 << endl;
                        return 1;
                }
        }
	
	if (file3 == "")
	{
                in_file3.open("movie-actor.txt");
                if(!in_file3.good())
                {
                        cout << "Warning: cannot open file named movie-actor.txt" << endl;
                        return 1;
                }
	}
	else
        {
                in_file3.open(file3.c_str());
                if (!in_file3.good())
                { 
                        cout << "Warning: cannot open file named " << file3 << endl;
                        return 1;
                }
        }
		
	
	map<string, string> actors_map;
	map<string, int> actors_vertices;
	map<int, string> actors_names;
	int num_actors = 0;
	int bacon_index = 0;
	string line = "";
	// map actor IDs to names
	while (getline(in_file1, line))
	{
		
		string actorID, actor;
		istringstream iss(line);
		getline(iss, actorID, '|');
		getline(iss, actor);
		
		if (actor == "Kevin Bacon")
		{
			// get Kevin Bacon's corresponding index
			bacon_index = num_actors;
		}
	
		actors_map[actorID] = actor;

		// map actor IDs to index from 0 to number of actors - 1 to be used with bacon_graph

		actors_vertices[actorID] = num_actors;

		// allow easy access to actor name from actor index

		actors_names[num_actors] = actor;
		line = "";
		num_actors++;
	}
	in_file1.close();
	
	const int VERTICESNUM = num_actors;
	Graph bacon_graph(VERTICESNUM);

	map<string, string> movies_map;
	string line2 = "";
	// map movie IDs to titles
	while (getline(in_file2, line2))
        {
               
                string movieID, movie;
                istringstream iss(line2);

                getline(iss, movieID, '|');
		getline(iss, movie);
		movies_map[movieID] = movie;
		line2 = "";
        }
	in_file2.close();

	// a map where movieID is the key and a set of the actors in the movie is the associated value
	map<string, set<string> > actors_of_movies_map;		
	string line3 = "";
	in_file3.clear();
	in_file3.seekg(0, ios::beg);
	while (getline(in_file3, line3))
        {
                string movieID, actorID;
                istringstream iss(line3);
                getline(iss, movieID, '|');

                getline(iss, actorID);
		// if a set of actors for the movie has already been created, add the actor to the set
		if (actors_of_movies_map.find(movieID) != actors_of_movies_map.end())
		{

			actors_of_movies_map[movieID].insert(actorID);
        	}

		// if the set has not been created yet then create it and insert the first actor to the set
		else
		{
			set<string> actors_of_movies_set;
			actors_of_movies_set.clear();
			actors_of_movies_map[movieID] = actors_of_movies_set;
			actors_of_movies_map[movieID].insert(actorID);
		}
	}
	in_file3.close();

	// iterate through all movies
	map<string, set<string> >::iterator j;
	for (j = actors_of_movies_map.begin(); j != actors_of_movies_map.end(); j++)
	{
		// vector to store all the actors in a particular movie
		vector<string> list_of_actors;
		set<string>::iterator k;
		// iterate through all actors of a particular movie
		for (k = j->second.begin(); k != j->second.end(); k++)
		{	
			// add actors to vector
			list_of_actors.push_back(*k);
			
		}
		// the vector allows for easy retrieving of actors compared to set

		int edges_count = list_of_actors.size() - 1;
		// the index for the actor that will be adding edges to
		int current_actor = 0;
		// add edges between all combinations of two  actors in the same movie	
		for (int l = 0; l < list_of_actors.size() - 1; l++)
		{
			
			int edges_left = edges_count;
			int other_actor = list_of_actors.size() - 1;
			while (edges_left != 0)
			{
				string mystring = j->first;
				//addEdge takes a int not string for edge value to have to convert
				int IDedge = atoi(mystring.c_str());
				// using index get current actor ID
				string current_to_add = list_of_actors[current_actor];
				//using index get actor IDs for all other actors that were in the movie besides current actor to add edges between
				string other_to_add = list_of_actors[other_actor];
				// find the corresponding index matched with current actor ID
				int current_vertex = actors_vertices[current_to_add];
				// find the corresponding index matched with all the other actors IDs
				int other_vertex = actors_vertices[other_to_add];
				// only add edge if there isnt one already between two actors
				if(!bacon_graph.hasEdge(current_vertex, other_vertex))
				{
					bacon_graph.addEdge(current_vertex, other_vertex, IDedge);
				}
				
				// get the next actor to add edge with current actor
				other_actor--;
				// decrement edges to add to current actor
				edges_left--;

			}
			// get next current actor to add edges to
			current_actor++;
			// number of edges to add to new current actor is one less than the previous current actor
			edges_count--;
		}
	}

	int source = bacon_index;
        vector<int> distance(VERTICESNUM, -1);
        vector<int> go_through(VERTICESNUM, -1);
        bacon_graph.BFS(source, distance, go_through);

	while (true)
        {
                cout << "The bacon number of an actor is the number of degrees of separation he/she has from Kevin Bacon. Those actors who have worked directly with Kevin Bacon have a bacon number of 1." << endl;
                cout << "This application helps you find the bacon number of an actor." << endl << "Enter exit to quit the program" << endl << "Please enter an actor's name (case-sensitive): " << endl;
		
		string actor_name;
		int actor_index;
		getline(cin, actor_name);

		if (actor_name == "Exit" || actor_name == "exit")
		{
			return 0;
		}

		map<string, string>::iterator m;
		int count = 0;
		// find the corresponding index of the actor name for the bacon_graph
		for (m = actors_map.begin(); m != actors_map.end(); m++)
		{
			if ( m->second == actor_name)
			{
				actor_index = actors_vertices[m->first];
				count++;
			}
		}
	
		// if corresponding index was never found then that actor is not in the file
		if (count == 0)
		{
			cout << "The actor name: " << actor_name << " does not exist" << endl;
		}
		
		else
		{
			// get number of edges between actor and Kevin Bacon
			int bacon_number = distance[actor_index];
		
			// if no edge, state it
			if (bacon_number == -1)
			{
				cout << "There is no path between " << actor_name << " and " << "Kevin Bacon" << endl;
			}
			else
			{
		
	
				cout << "The bacon number for " << actor_name << " is: " << bacon_number << endl;
		
				int current_index = actor_index;
                		for (int i = 0; i < bacon_number; i++)
                		{
                        		int temp_mov_edge = bacon_graph.getEdge(current_index, go_through[current_index]);
                        		stringstream ss;
                        		ss << temp_mov_edge;
					// convert from movie id edge from int to string
                        		string movieID_edge = ss.str();

					// print out path from actor to Kevin Bacon

                        		cout << actors_names[current_index] << " appeared in " << movies_map[movieID_edge] << " with " << actors_names[go_through[current_index]] << endl;
                        		current_index = go_through[current_index];
        
                		}
			}
                
                    
        	}
	cout << endl << "************************************************" << endl << endl;
	}            
     
 
    return 0;
}


		    
