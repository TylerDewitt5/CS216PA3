// It provides the implementation of the Graph class
#include <list>     // create a queue from a list
#include <cassert>
#include "Graph.h"

// default constructor
Graph::Graph(int numVertices):adj(Matrix<int>(numVertices, numVertices, -1))
{
}

bool Graph::hasEdge(int v, int w)
{
    assert(v>=0 && v < adj.GetSizeX() && w >=0 && w < adj.GetSizeX());
    if (adj(v, w)==-1)
        return false;
    return true;
}

// Please provide your implementation
// for the following three member functions
void Graph::addEdge(int v, int w, int edge)
{
	if (v >= adj.GetSizeX() && w >= adj.GetSizeY())
	{
		cout << "There are no vertices " << v << " and  " << w << " in the graph" << endl;
	}
	else if (v >= adj.GetSizeX())
	{
		cout << "There is no vertex " << v << " in the graph" << endl;
	}
	else if (w >= adj.GetSizeY())
	{
		cout << "There is no vertex " << w << " in the graph" << endl;
	}
	else
	{
		adj(v, w) = edge;
		adj(w, v) = edge;
	}
}

int Graph::getEdge(int v, int w)
{
	if (v >= adj.GetSizeX() && w >= adj.GetSizeY())
        {
                cout << "There are no vertices " << v << " and  " << w << " in the graph" << endl;
        }
        else if (v >= adj.GetSizeX())
        {
                cout << "There is no vertex " << v << " in the graph" << endl;
        }
        else if (w >= adj.GetSizeY())
        {
                cout << "There is no vertex " << w << " in the graph" << endl;
        }
	else
	{
		return adj(v, w);
	}

	return (-1000);
}

void Graph::BFS(int s, vector<int>& distance, vector<int>& go_through)
{
	list<int> Q;
	distance[s] = 0;
	Q.push_back(s);

	// pointers to tell if a vertex has been visited already
	bool *visited = new bool[distance.size()];
	// mark all vertices as unvisited
	for (int i = 0; i < distance.size(); i++)
	{
		visited[i] = false;
	}

	// except for the source vertex
	visited[s] = true;

	// unless the queue is empty						
	while (!Q.empty())
	{
		// use vertex at front of queue to check for adjacent vertices
		int current = Q.front();
		// remove vertex your using
		Q.pop_front();
		// iterate through all 7 vertices to find adjacent vertices to current
		for (int i = 0; i < distance.size(); i++)
		{
			// make sure this vertex is adjacent to current and hasn't been visited already
			if ((adj(current, i) != -1) && (adj(i, current) != -1) && (!visited[i]))
			{
				// add unvisited adjacent vertex to queue
				Q.push_back(i);
				// add edge to distance from vertex
				distance[i] = distance[current] + 1;
				// the added part for Lab12
				go_through[i] = current;
				// mark adjacent unvisited matrix as now visited
				visited[i] = true;
			}
		}
	}
	// delete dynamically allocated pointers
	delete [] visited;
	

}

